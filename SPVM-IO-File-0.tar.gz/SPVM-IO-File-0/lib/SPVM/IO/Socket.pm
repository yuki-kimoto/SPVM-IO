package SPVM::IO::Socket;

our $VERSION = '0.01';

1;

=head1 NAME

SPVM::IO::Socket - Interface of Socket

=head1 SYNOPSYS
  
  use IO::Socket;

=head1 DESCRIPTION

L<SPVM::IO::Socket> provides socket utilities.

B<SPVM::IO::Socket is now development release. The changes without warnings are offten quit will be done.>
