# SPVM::IO

SPVM::IO is a I/O modules for File IO, Socket, select.

