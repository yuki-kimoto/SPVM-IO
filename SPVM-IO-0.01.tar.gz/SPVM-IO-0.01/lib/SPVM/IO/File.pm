package SPVM::IO::File;

1;

=head1 NAME

SPVM::IO::File - File Input/Output

=head1 SYNOPSYS
  
  use IO::File;

=head1 DESCRIPTION

L<SPVM::IO::File> provides file input/output stream.

B<SPVM::IO::File is now development release. The changes without warnings are offten quit will be done.>
