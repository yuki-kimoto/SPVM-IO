package SPVM::IO::FileHandle;

1;

=head1 NAME

SPVM::IO::FileHandle - File handle

=head1 SYNOPSYS
  
  use SPVM::IO::FileHandle;

=head1 DESCRIPTION

L<SPVM::IO::FileHandle> is file handle object for L<SPVM::IO::File>.
