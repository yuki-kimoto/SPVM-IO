package SPVM::IO::Select;

our $VERSION = '0.01';

1;

=head1 NAME

SPVM::IO::Select - Select

=head1 SYNOPSYS
  
  use IO::Select;

=head1 DESCRIPTION

L<SPVM::IO::Select> provides file input/output stream.

B<SPVM::IO::Select is now development release. The changes without warnings are offten quit will be done.>
