package SPVM::IO::Socket::INET;

1;

=head1 NAME

SPVM::IO::Socket::INET - Socket ipv4 implementation

=head1 SYNOPSYS
  
  use IO::Socket::INET;

=head1 DESCRIPTION

L<SPVM::IO::Socket::INET> provides socket utilities.

B<SPVM::IO::Socket::INET is now development release. The changes without warnings are offten quit will be done.>
